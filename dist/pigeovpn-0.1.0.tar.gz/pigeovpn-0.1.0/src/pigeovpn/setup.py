'''
Create the credentials.txt file from which the .ovpn file roots the 'auth-user-pass'
'''

import os
from pathlib import Path
import json

from pigeovpn.constants import CREDS_FILE, JSON_CONF
from pigeovpn.external_commands import execute_sudo_commands

def modify_json(key:str, value) -> None:
    """Modify values of the json configuration"""
    # Load the file
    with open(JSON_CONF, "r") as file:
           config = json.load(file)
    
    # Change the value
    config[key] = value
    with open(JSON_CONF, "w") as file:
        json.dump(config, file)


def setup_credentials(username: str, password: str) -> None:
    """
    Create a credentials file {CREDS_FILE} containing
        username\n
        password\n
    with mode 600
    From this file the .ovpn files read the setup_credentials
    """
    sudo_command = ' '.join([
        'sudo',
        'sh',
        '-c',
        f'\'echo "{username}\'\n\'{password}" > {CREDS_FILE}\'',
        'sudo',
        f'chmod 600 {CREDS_FILE}'
        ])

    return execute_sudo_commands(sudo_command)


def setup_ovpnDirectory(directory: str | Path) -> None:
    """
    From the settings page, insert into the json file the directory given by the user
    """
    modify_json("ovpn_directory", directory)


def check_showing_settings() -> bool:
    """
    Check if the settings/welcome page should be shown
    """

    with open(JSON_CONF, "r") as file:
        config = json.load(file)

    return config["show_settings"]

def update_showing_settings() -> None:
    modify_json("show_settings", False)
